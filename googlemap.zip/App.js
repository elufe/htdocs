import React, {Component} from "react";
import { StyleSheet, Text, View } from "react-native";
import { MapView } from "expo";
//import GeolocationExample from './GeolocationExample.js'

export default class App extends React.Component {
/*
  state = {
     initialPosition: 'unknown',
     lastPosition: 'unknown',
  }
  watchID: ?number = null;

  componentDidMount = () => {
     navigator.geolocation.getCurrentPosition(
        (position) => {
           const initialPosition = JSON.stringify(position);
           this.setState({ initialPosition });
        },
        (error) => alert(error.message),
        { enableHighAccuracy: true, timeout: 20000, maximumAge: 10 }
     );
     this.watchID = navigator.geolocation.watchPosition((position) => {
        const lastPosition = JSON.stringify(position);
        this.setState({ lastPosition });
     });
  }
  componentWillUnmount = () => {
     navigator.geolocation.clearWatch(this.watchID);
  }*/

  constructor(props) {
      super(props);

      this.state = {
        isLoading: true,
        markers: [],
      };
    }
    fetchMarkerData() {
      fetch('https://feeds.citibikenyc.com/stations/stations.json')
        .then((response) => response.json())
        .then((responseJson) => {
          this.setState({
            isLoading: true,
            markers: responseJson.stationBeanList,
          });
        })
        .catch((error) => {
          console.log(error);
        });
    }
  componentDidMount() {
      this.fetchMarkerData();
  }


  render() {
    return (
    //  <GeolocationExample />
      <MapView
        style={{
          flex: 1
        }}
        initialRegion={{
          latitude: this.state.initialPosition.coords.latitude,
          longitude: this.state.initialPosition.coords.longitude,
          latitudeDelta: 0.0922,
          longitudeDelta: 0.0421
        }}
      />
    );
  }
}
