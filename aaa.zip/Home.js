import React from 'react'
import GeolocationExample from './GeolocationExample.js'

const Home = () => {
   return (
      <GeolocationExample />
   )
}
export default Home
